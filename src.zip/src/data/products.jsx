export const products = [
    {
      id: 1,
      name: "Moonstone Hoodie",
      description: "Lunar comfort, 100% cosmic cotton.",
      price: 59.99,
      image: "/images/moon-hoodie.jpg", // put placeholder images
    },
    {
      id: 2,
      name: "Galactic Sneakers",
      description: "Walk among stars.",
      price: 89.99,
      image: "/images/sneakers.jpg",
    },
    // Add more...
  ];
  