import React, { useState ,useEffect} from "react";
import Navbar from "./components/navbar.jsx";
import HeroSection from "./components/heroSection.jsx";
import TrendingItemsSection from "./components/trendingItemsSection.jsx";
import Footer from "./components/footer.jsx";
import SignUpBanner from "./components/signUpBanner.jsx";
import LoginBanner from "./components/loginBanner.jsx";
import Shop from "./pages/shop.jsx";
import { AnimatePresence } from "framer-motion";
import { motion } from "framer-motion";
import { BrowserRouter, Routes,Route } from "react-router-dom";


function App() {
  const [showBanner, setShowBanner] = useState(true);  // always true for showing banner
  const [showLogin, setShowLogin] = useState(false);
  //const [isSwitching, setIsSwitching] = useState(false);

  
  const handleBannerClose = () => {
    setShowBanner(false);
   
    // Optionally store it in localStorage if you want to track dismissals
    localStorage.setItem("hasVisited", "true");
  };

  const handleLoginClose = () => {
    setShowLogin(false);
  }

  useEffect(() => {
    if (showBanner || showLogin) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "auto";
    }
  
    return () => {
      document.body.style.overflow = "auto";
    };
  }, [showBanner, showLogin]);

  return (
   
    <div className="font-montserrat-normal text-black relative">
      {/* Main UI with blur when banner is shown */}
         <div
           className={`${(showBanner || showLogin) ? "blur-sm scale-[1.4] brightness-90" : ""} transition-all duration-500`} >
           <Navbar setShowLogin={setShowLogin} />
           <HeroSection />
           <TrendingItemsSection />
           <Footer />
          
           
         </div>

      {/* Banner overlay on top */}
        
      <AnimatePresence>
        {showBanner && (
          <motion.div
            key="signup-banner"
            initial={{ opacity: 0, x:1500 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 1500 }}
            transition={{ duration: 0.5}}
            className="fixed top-0 w-full h-full z-50  flex items-start justify-center mb-20"
          >
            <SignUpBanner
              onClose={handleBannerClose}
              onSwitch={() => {
                setShowLogin(true);
                setShowBanner(false);
                
              }}
            />
          </motion.div>
        )}
      
        {showLogin && (
          <motion.div
            key="login-banner"
            initial={{ opacity: 0, x: -1500 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -1500 }}
            transition={{ duration: 0.5 }}
            className="fixed top-0 w-full h-full z-50  flex items-start justify-center mb-20"
          >
            <LoginBanner
              onClose={handleLoginClose}
              onSwitch={() => {
                setShowBanner(true);
                setShowLogin(false);
                
              }}
              
            />
          </motion.div>
        )}
      </AnimatePresence>
      <BrowserRouter>
          <Routes>
            <Route path="/shop" element={<Shop />} />
          </Routes>
      </BrowserRouter>
      </div>
    );
}

export default App;
